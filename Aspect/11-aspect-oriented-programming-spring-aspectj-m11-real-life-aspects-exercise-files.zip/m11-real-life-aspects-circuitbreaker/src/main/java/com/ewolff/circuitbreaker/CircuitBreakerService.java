package com.ewolff.circuitbreaker;

public interface CircuitBreakerService {

	void erroneousMethod();
	
}
