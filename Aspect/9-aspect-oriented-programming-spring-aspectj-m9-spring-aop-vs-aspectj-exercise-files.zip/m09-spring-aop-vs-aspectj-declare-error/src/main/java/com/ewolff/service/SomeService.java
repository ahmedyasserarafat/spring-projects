package com.ewolff.service;

import java.sql.Connection;
import java.sql.SQLException;

public class SomeService {

/*  private Connection connection;

  public void doSomeJDBCstuff() {
    try {
      connection.close();
    } catch (SQLException e) {
      // e.printStackTrace();
    }
  }
*/
  
}
