package com.ewolff.demo;



public class DemoClass {

	public void advicedMethod() {
	}

	public void callsTheAdvicedMethohd() {
		advicedMethod();
	}
	
}
