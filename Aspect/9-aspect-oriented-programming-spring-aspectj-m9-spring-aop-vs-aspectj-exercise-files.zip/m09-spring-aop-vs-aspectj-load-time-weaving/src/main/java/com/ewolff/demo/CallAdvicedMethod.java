package com.ewolff.demo;

public class CallAdvicedMethod {
	
	public static void main(String[] args) {
		DemoClass demoClass = new DemoClass();
		demoClass.advicedMethod();
	}

}
