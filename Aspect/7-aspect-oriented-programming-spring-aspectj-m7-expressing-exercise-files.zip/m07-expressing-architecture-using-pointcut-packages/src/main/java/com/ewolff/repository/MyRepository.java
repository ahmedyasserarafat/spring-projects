package com.ewolff.repository;

public class MyRepository {

	public void doIt() {
	}

	public void throwsException() {
		throw new RuntimeException();
	}

}
