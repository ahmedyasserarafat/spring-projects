package com.ewolff.service;

public class MyService {

	public void doIt() {

	}

}
