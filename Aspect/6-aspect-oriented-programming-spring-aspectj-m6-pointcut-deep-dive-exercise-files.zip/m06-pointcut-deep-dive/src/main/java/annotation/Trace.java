package annotation;

public @interface Trace {

}
