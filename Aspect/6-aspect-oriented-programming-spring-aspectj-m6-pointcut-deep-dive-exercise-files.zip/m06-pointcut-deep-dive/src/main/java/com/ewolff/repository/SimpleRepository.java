package com.ewolff.repository;

import org.springframework.stereotype.Repository;

@Repository
public class SimpleRepository {
	
	public void doSomething() {
		
	}

}
