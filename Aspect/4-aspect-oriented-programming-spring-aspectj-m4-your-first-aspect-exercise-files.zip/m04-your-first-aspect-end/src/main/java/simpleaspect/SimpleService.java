package simpleaspect;

import org.springframework.stereotype.Service;

@Service
public class SimpleService {

	public void doSomething() {

	}

	public void doSomethingElse(int dummy) {

	}
	
}
