package simpleaspect;

import org.springframework.stereotype.Service;

@Service
public class SimpleService {

	public void doSomethingElse(int i) {

	}
	
}
